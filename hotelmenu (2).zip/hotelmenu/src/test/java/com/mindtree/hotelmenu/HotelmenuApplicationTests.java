package com.mindtree.hotelmenu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelmenuApplicationTests {

	@Test
	void contextLoads() {
	}

}
