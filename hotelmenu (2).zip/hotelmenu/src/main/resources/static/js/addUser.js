validate=()=>{
											var username = document.getElementById("name").value;
											 var user = /^[A-Z][a-zA-Z0-9]{8,18}$/;
											if(user.test(username))
											{

											}
											else
											{
											    alert("Invalid user name...first character should be Uppercase and username should be between 8 to 18 letters")
											    return false;
											}
											var psw = document.getElementById("password").value;
											var ps = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{7,16}$/;
											if(ps.test(psw))
											{
											    
											}
											else
											{
											    alert("invalid passoword")
											    return false;
											}
											var cpsw = document.getElementById("cpassword").value;
											if(cpsw==psw)
											{
												
											}
											else
											{
												
												alert("password do not match with confirm password")
												return false;
											}
											
				}