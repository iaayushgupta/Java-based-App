package com.mindtree.hotelmenu.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.mindtree.hotelmenu.entity.User;
import com.mindtree.hotelmenu.service.UserSerivce;

@Controller
@SessionAttributes
public class UserController {

	@Autowired
	private UserSerivce userService;

	@RequestMapping("/")
	public String addUser(Model model) {
		model.addAttribute("user", new User());
		return "adduser";
	}

	@PostMapping("/save")
	public String saveUser(@ModelAttribute("user") User user, Model model) {
		userService.addUser(user);
		model.addAttribute("userName", user.getUserName());
		return "redirect:/showinside";
	}

	@RequestMapping("/showinside")
	public String showInside(Model model) {
		model.addAttribute("userName", userService.findLast());
		return "showinside";
	}

}
