package com.mindtree.hotelmenu.entity;

import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Item {

	@Override
	public String toString() {
		return "Item [itemId=" + itemId + ", itemName=" + itemName + ", itemType=" + itemType + ", cost=" + cost
				+ ", Quantity=" + Quantity + ", rating=" + rating + ", users=" + users + ", averageRating="
				+ averageRating + "]";
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long itemId;
	private String itemName;
	private String itemType;
	private float cost;
	private int Quantity;

	@ElementCollection
	private List<Float> rating;

	public List<Float> getRating() {
		return rating;
	}

	public void setRating(List<Float> rating) {
		this.rating = rating;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	@ManyToMany(mappedBy = "items")
	private List<User> users;
	private double averageRating;

	public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	public double getAverageRating() {
		return averageRating;
	}

	public void setAverageRating(double d) {
		this.averageRating = d;
	}

}
