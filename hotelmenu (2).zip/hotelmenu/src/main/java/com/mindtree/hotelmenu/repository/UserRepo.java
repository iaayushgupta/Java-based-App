package com.mindtree.hotelmenu.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.hotelmenu.entity.User;

@Repository
public interface UserRepo extends JpaRepository<User, Long> {

	User findByuserName(String userName);

	Optional<User> findByUserName(String userName);

}
