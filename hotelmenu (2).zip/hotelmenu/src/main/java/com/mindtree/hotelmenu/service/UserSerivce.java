package com.mindtree.hotelmenu.service;

import com.mindtree.hotelmenu.entity.User;

public interface UserSerivce {

	User addUser(User user);

	User findByName(String userName);

	String findLast();

	float getTotalCost(String userName);

	void saveUser(User user, String userName);

	void saveUser1(User user, String userName);
}
