package com.mindtree.hotelmenu.controller;

import java.util.ArrayList;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.mindtree.hotelmenu.entity.Item;
import com.mindtree.hotelmenu.entity.User;
import com.mindtree.hotelmenu.service.ItemService;
import com.mindtree.hotelmenu.service.UserSerivce;

@Controller
@SessionAttributes
public class ItemController {

	@Autowired
	private ItemService itemService;

	@Autowired
	private UserSerivce userService;
	@Autowired
	UserController userController;

	@RequestMapping("/createitem")
	public String addUser(Model model) {
		model.addAttribute("item", new Item());
		return "createitem";
	}

	@PostMapping("/saves")
	public String addItem(@ModelAttribute("item") Item item) {
		itemService.addItem(item);
		return "createitem";
	}

	@RequestMapping("/veg/{userName}")
	public String showVegList(ModelMap model, @PathVariable("userName") String userName) {
		model.addAttribute("veglist", itemService.showVegList("veg"));
		model.addAttribute("user", userService.findByName(userName));
		model.addAttribute("userName", userName);
		return "veglist";
	}

	@RequestMapping("/nonveg/{userName}")
	public String showVegList1(ModelMap model, @PathVariable("userName") String userName) {
		model.addAttribute("veglist", itemService.showVegList("nonveg"));
		model.addAttribute("user", userService.findByName(userName));
		model.addAttribute("userName", userName);
		return "nonveglist";
	}

	@RequestMapping("/getitem/updateveg/{itemId}")
	public String update(@PathVariable("itemId") int itemId, Model model) {
		Item item = itemService.findById(itemId);
		model.addAttribute("item", item);
		return "updateveg";
	}

	@PostMapping("saveupdate")
	public String saveUpdate(@ModelAttribute("item") Item item, Model model) {
		itemService.updateItem(item);
		model.addAttribute("userName", userService.findLast());
		return "redirect:/showinside";
	}

	@PostMapping("/checkboxes/{userName}")
	public String checkbox(@ModelAttribute User user, @PathVariable("userName") String userName) {
		System.out.println(user.getSelectedItem());
		userService.saveUser(user, userName);
		return "redirect:/showinside";
	}

	@PostMapping("/checkbox/{userName}")
	public String checkbox1(@ModelAttribute User user, @PathVariable("userName") String userName) {
		userService.saveUser1(user, userName);
		return "redirect:/showinside";
	}

	@RequestMapping("average/{userName}")
	public String giveRating(ModelMap model, @PathVariable("userName") String userName) {
		model.addAttribute("items", itemService.showList(userName));
		model.addAttribute("user", new User());
		return "rating";
	}

	@PostMapping("/average/saved/{userName}")
	public String saveRating(@ModelAttribute User user, Model model) {
		System.out.println(user);
		itemService.saveRating(user);
		model.addAttribute("userName", userService.findLast());
		return "redirect:/showinside";
	}

	@RequestMapping("getitem/{userName}")
	public String getItems(ModelMap model, @PathVariable("userName") String userName) {
		model.addAttribute("items", itemService.getItems(userName));
		model.addAttribute("cost", userService.getTotalCost(userName));
		model.addAttribute("userName", userService.findLast());
		return "showinside";
	}

	@RequestMapping("excel/{userName}")
	public String exportToExcel(ModelMap model, @PathVariable("userName") String userName) {
		itemService.printitembyuser(userName, itemService.getItems(userName), userService.getTotalCost(userName));
		return "redirect:/showinside";
	}
}
