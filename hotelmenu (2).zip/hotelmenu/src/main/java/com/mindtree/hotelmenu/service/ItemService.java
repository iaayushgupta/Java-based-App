package com.mindtree.hotelmenu.service;

import java.util.List;

import com.mindtree.hotelmenu.entity.Item;

import com.mindtree.hotelmenu.entity.User;

public interface ItemService {

	Item addItem(Item item);

	List<Item> showVegList(String type);

	List<Item> getItems(String userName);

	List<Item> showList(String userName);

	Item findById(long itemId);

	float getCost(List<Item> itemlist);

	void saveRating(User user);

	void updateItem(Item item);

	List<Item> itemlistuser(String userName);

	void printitembyuser(String userName, List<Item> items, float totalCost);

}
