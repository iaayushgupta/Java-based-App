package com.mindtree.hotelmenu.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.hotelmenu.entity.Item;

@Repository
public interface ItemRepo extends JpaRepository<Item, Long> {

	Item findByitemName(String id);

}
