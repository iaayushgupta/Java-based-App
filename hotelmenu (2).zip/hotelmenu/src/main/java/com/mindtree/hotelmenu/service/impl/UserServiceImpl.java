package com.mindtree.hotelmenu.service.impl;

import java.util.ArrayList;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.hotelmenu.entity.Item;
import com.mindtree.hotelmenu.entity.User;
import com.mindtree.hotelmenu.repository.ItemRepo;
import com.mindtree.hotelmenu.repository.UserRepo;
import com.mindtree.hotelmenu.service.ItemService;
import com.mindtree.hotelmenu.service.UserSerivce;

@Service
public class UserServiceImpl implements UserSerivce {

	@Autowired
	private UserRepo userRepo;
	@Autowired
	private ItemRepo itemRepo;
	@Autowired
	private ItemService itemSerivce;

	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return userRepo.save(user);
	}

	@Override
	public User findByName(String userName) {
		// TODO Auto-generated method stub
		return userRepo.findByuserName(userName);
	}

	@Override
	public String findLast() {
		// TODO Auto-generated method stub
		long Id = 0;
		for (User user : userRepo.findAll()) {
			if (user.getUserId() > Id) {
				Id = user.getUserId();
			}
		}
		return userRepo.findById(Id).get().getUserName();
	}

	@Override
	public float getTotalCost(String userName) {
		// TODO Auto-generated method stub
		User user = findByName(findLast());
		float totalcost = 0;
		for (Item item : itemSerivce.itemlistuser(userName)) {
			float cost = item.getQuantity() * item.getCost();

			totalcost = totalcost + cost;
		}
		return totalcost;
	}

	@Override
	public void saveUser(User user, String userName) {
		// TODO Auto-generated method stub
		User newUser = findByName(userName);
		System.out.println(user.getSelectedItem());
		user.getSelectedItem().forEach(id -> {
			Item item = itemRepo.findById(id).get();
			user.getQuantity().forEach(quantity -> {
				item.setQuantity(quantity);
			});
			item.getUsers().add(newUser);
			newUser.getItems().add(item);
			userRepo.save(newUser);
			itemRepo.save(item);
		});
	}

	@Override
	public void saveUser1(User user, String userName) {
		// TODO Auto-generated method stub
		User newUser = findByName(userName);
		user.getItemId1().forEach(id -> {
			Item item = itemRepo.findById(id).get();
			user.getQuantity().forEach(quantity -> {
				item.setQuantity(quantity);
			});
			item.getUsers().add(newUser);
			newUser.getItems().add(item);
			userRepo.save(newUser);
			itemRepo.save(item);
		});
	}

}
