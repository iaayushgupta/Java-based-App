package com.mindtree.hotelmenu.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.hotelmenu.entity.Item;
import com.mindtree.hotelmenu.entity.User;

import com.mindtree.hotelmenu.repository.ItemRepo;
import com.mindtree.hotelmenu.repository.UserRepo;
import com.mindtree.hotelmenu.service.ItemService;
import com.mindtree.hotelmenu.service.UserSerivce;

@Service
public class ItemServiceImpl implements ItemService {

	@Autowired
	private ItemRepo itemRepo;
	@Autowired
	private UserRepo userRepo;
	@Autowired
	private UserSerivce userService;

	@Override
	public Item addItem(Item item) {
		// TODO Auto-generated method stub
		return itemRepo.save(item);
	}

	@Override
	public List<Item> showVegList(String type) {
		// TODO Auto-generated method stub
		List<Item> itemlist = new ArrayList<Item>();
		List<Item> items = itemRepo.findAll();
		System.out.println(items);
		for (Item item : items) {
			System.out.println(item);
			String type1 = item.getItemType();
			if (type1.equalsIgnoreCase(type)) {
				itemlist.add(item);
			}
		}
		System.out.println(itemlist);
		return itemlist;
	}

	@Override
	public Item findById(long itemId) {
		// TODO Auto-generated method stub
		return itemRepo.findById(itemId).get();
	}

	@Override
	public float getCost(List<Item> itemlist) {
		// TODO Auto-generated method stub
		List<Float> costs = new LinkedList<>();
		itemlist.forEach(item -> {
			float cost = item.getQuantity() * item.getCost();
			costs.add(cost);
		});
		return costs.stream().reduce((float) 0, (ans, i) -> ans + i);
	}

	@Override
	public List<Item> showList(String userName) {
		// TODO Auto-generated method stub
		User user = userService.findByName(userName);
		return user.getItems();
	}

	int index = 0;

	@Override
	public void saveRating(User user) {
		// TODO Auto-generated method stub
		System.out.println(user);
		System.out.println(user.getSelectedItem());
		user.getSelectedItem().forEach(id -> {
			Item obj = itemRepo.findById(id).get();
			obj.getRating().add((float) user.getQuantity().get(index));
			itemRepo.save(obj);
			index++;
		});
		index = 0;
		List<Item> list = itemRepo.findAll();
		list.stream().forEach(item -> {
			float total = item.getRating().stream().reduce((float) 0, (a, b) -> a + b);
			System.out.println(total);
			if(item.getRating().size()>0) {
			item.setAverageRating(total / item.getRating().size() * (1.0));
			}
			System.out.println(item.getAverageRating());
			itemRepo.save(item);
			
		});

	}

	@Override
	public List<Item> getItems(String userName) {

		// TODO Auto-generated method stub
		return itemlistuser(userName);
	}

	@Override
	public void updateItem(Item item) {
		User user = userRepo.findByuserName(userService.findLast());

		// TODO Auto-generated method stub
		List<Item> items = itemRepo.findAll();
		items.forEach(item1 -> {
			if (item1.getItemId() == item.getItemId())
				item1.setQuantity(item.getQuantity());
			itemRepo.save(item1);
		});

	}

	@Override
	public List<Item> itemlistuser(String userName) {
		// TODO Auto-generated method stub
		User user = userRepo.findByuserName(userName);
		List<Item> items = new ArrayList<>();
		for (Item item : itemRepo.findAll()) {
			for (User user1 : item.getUsers()) {
				if (user1.getUserId() == user.getUserId()) {
					items.add(item);
				}

			}
		}
		return user.getItems();

	}

	int i = 0;

	@Override
	public void printitembyuser(String userName, List<Item> items, float totalCost) {
		// TODO Auto-generated method stub
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("item details");
		XSSFRow header = sheet.createRow(0);
		header.createCell(0).setCellValue("Item Id");
		header.createCell(1).setCellValue("Item Name");
		header.createCell(2).setCellValue("Item Rating");
		header.createCell(3).setCellValue("Item Cost");
		header.createCell(4).setCellValue("Item quantity");
		header.createCell(5).setCellValue("User Name");
		header.createCell(6).setCellValue("Total Cost");
		int rownum = 1;
		for (Item item : items) {
			Row row = sheet.createRow(rownum++);
			Cell cell1 = row.createCell(0);
			cell1.setCellValue(item.getItemId());
			Cell cell2 = row.createCell(1);
			cell2.setCellValue(item.getItemName());
			Cell cell3 = row.createCell(2);
			cell3.setCellValue(item.getAverageRating());
			Cell cell4 = row.createCell(3);
			cell4.setCellValue(item.getCost());
			Cell cell5 = row.createCell(4);
			cell5.setCellValue(item.getQuantity());
			Cell cell6 = row.createCell(5);
			cell6.setCellValue(userName);
		}
		Cell cell7 = sheet.createRow(rownum).createCell(6);
		cell7.setCellValue(totalCost);

		try {
			FileOutputStream fos = new FileOutputStream("D:/itemDetail.xlsx");
			workbook.write(fos);

			fos.close();
			workbook.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

}
