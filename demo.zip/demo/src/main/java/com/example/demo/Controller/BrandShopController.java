package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Brand;
import com.example.demo.Entity.Shop;
import com.example.demo.Service.BrandService;
import com.example.demo.Service.ShopService;


@RestController
public class BrandShopController {

	@Autowired
	static BrandService brandservice;
	@Autowired
	static ShopService shopservice ;
	
	@PostMapping("/setbrand")
	public void AddBrandDetail(Brand brand) {
		brandservice.AddBrand(brand);
	}
	@PostMapping("/setshop")
	public void AddShopDetail(Shop shop) {
		shopservice.AddShopDetail(shop);
	}
}
