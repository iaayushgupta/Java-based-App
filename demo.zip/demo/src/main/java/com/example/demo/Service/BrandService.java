package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Brand;
import com.example.demo.Repository.BrandRepository;



@Service
public class BrandService {
	@Autowired
	static BrandRepository brandrepository;
	public void AddBrand(Brand brand) {
		brandrepository.save(brand);
	}
}
