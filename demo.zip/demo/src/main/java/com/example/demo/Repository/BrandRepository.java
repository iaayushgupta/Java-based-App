package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.Brand;

public interface BrandRepository extends JpaRepository<Brand,Long>{

}
