package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.Entity.Shop;
import com.example.demo.Repository.ShopRepository;



public class ShopService {
	@Autowired
	  static ShopRepository shoprepository; 
		public void AddShopDetail(Shop shop) {
			shoprepository.save(shop);
		}
}
