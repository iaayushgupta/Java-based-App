package com.example.demo.Entity;

import javax.persistence.Entity;

@Entity
public class Brand {
	@Override
	public String toString() {
		return "Brand [brandid=" + brandid + ", brandname=" + brandname + ", noOfClothes=" + noOfClothes + ", id=" + id
				+ "]";
	}
	private long brandid;
	private String brandname;
	private long noOfClothes;
	private long id;
	public long getBrandid() {
		return brandid;
	}
	public void setBrandid(long brandid) {
		this.brandid = brandid;
	}
	public String getBrandname() {
		return brandname;
	}
	public void setBrandname(String brandname) {
		this.brandname = brandname;
	}
	public long getNoOfClothes() {
		return noOfClothes;
	}
	public void setNoOfClothes(long noOfClothes) {
		this.noOfClothes = noOfClothes;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
}
