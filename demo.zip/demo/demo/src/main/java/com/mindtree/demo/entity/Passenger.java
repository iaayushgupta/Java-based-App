package com.mindtree.demo.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Passenger implements Comparable<Passenger> {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int passengerId;
	private String passengerName;
	private String ticketCode;
	private String DOB;
	@ManyToOne(fetch = FetchType.EAGER)
	@JsonIgnore
	private Ship ship;

	public int getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(int passengerId) {
		this.passengerId = passengerId;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public String getTicketCode() {
		return ticketCode;
	}

	public void setTicketCode(String ticketCode) {
		this.ticketCode = ticketCode;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public Ship getShip() {
		return ship;
	}

	public void setShip(Ship ship) {
		this.ship = ship;
	}

	public Passenger() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int compareTo(Passenger o) {
		// TODO Auto-generated method stub
		if (this.DOB == o.DOB) {
			if (this.passengerId == o.passengerId) {
				return 0;
			} else if (this.passengerId < o.passengerId) {
				return 1;
			} else {
				return -1;
			}
		} else if ((this.DOB.compareToIgnoreCase(DOB)) < 0) {
			return 1;
		} else {
			return -1;
		}
	}

}
