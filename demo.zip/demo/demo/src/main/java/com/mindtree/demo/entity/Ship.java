package com.mindtree.demo.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Ship {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int shipId;
	private String shipName;
	private int totalCrewMember;
	private int shipCapacity;
	private int currentStrength;
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "ship")
	private List<Passenger> passengers;

	public int getShipId() {
		return shipId;
	}

	public void setShipId(int shipId) {
		this.shipId = shipId;
	}

	public String getShipName() {
		return shipName;
	}

	public void setShipName(String shipName) {
		this.shipName = shipName;
	}

	public int getTotalCrewMember() {
		return totalCrewMember;
	}

	public void setTotalCrewMember(int totalCrewMember) {
		this.totalCrewMember = totalCrewMember;
	}

	public int getShipCapacity() {
		return shipCapacity;
	}

	public void setShipCapacity(int shipCapacity) {
		this.shipCapacity = shipCapacity;
	}

	public int getCurrentStrength() {
		return currentStrength;
	}

	public void setCurrentStrength(int currentStrength) {
		this.currentStrength = currentStrength;
	}

	public List<Passenger> getPassengers() {
		return passengers;
	}

	public void setPassengers(List<Passenger> passengers) {
		this.passengers = passengers;
	}

	public Ship() {
		// TODO Auto-generated constructor stub
	}

}
