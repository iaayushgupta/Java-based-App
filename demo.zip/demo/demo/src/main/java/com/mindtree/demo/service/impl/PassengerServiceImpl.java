package com.mindtree.demo.service.impl;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.demo.entity.Passenger;
import com.mindtree.demo.entity.Ship;
import com.mindtree.demo.repository.PassengerRepo;
import com.mindtree.demo.repository.ShipRepo;
import com.mindtree.demo.service.PassengerService;
import com.mindtree.demo.service.ShipService;

@Service
public class PassengerServiceImpl implements PassengerService {

	@Autowired
	private PassengerRepo par;
	@Autowired
	private ShipService shipservice;
	@Autowired
	private ShipRepo shir;

	@Override
	public Passenger addPassenger(int shipId, Passenger passenger) {
		// TODO Auto-generated method stub

		passenger.setTicketCode(generateTicketCode(shipId, passenger));
		Ship ship = shipservice.findShip(shipId, passenger);
		passenger.setShip(ship);
		return passenger;

	}

	@Override
	public String generateTicketCode(int shipId, Passenger passenger) {
		// TODO Auto-generated method stub
		String ticketName = "";
		Ship ship = shir.findById(shipId).get();
		String sName = ship.getShipName();
		for (int i = 0; i < 2; i++) {
			ticketName = ticketName + sName.charAt(i);
		}
		String yob = passenger.getDOB();
		for (int i = yob.length() - 1; i >= 0; i++) {
			ticketName = ticketName + yob.charAt(i);
		}
		ticketName = ticketName + "_";
		String pName = passenger.getPassengerName();
		ticketName = ticketName + pName.charAt(0);
		ticketName = ticketName + pName.charAt(pName.length() - 1);
		return ticketName;
	}

	@Override
	public Passenger showPassenger(String ticketCode) {
		// TODO Auto-generated method stub
		List<Passenger> passengers = par.findAll();
		for (Passenger passenger : passengers)
			if (passenger.getPassengerName().equalsIgnoreCase(ticketCode) == true)
				return passenger;
		return null;
	}

	@Override
	public List<Passenger> sortPassenger() {
		// TODO Auto-generated method stub
		List<Passenger> passengers = par.findAll();
		Collections.sort(passengers);
		return passengers;
	}

}
