package com.mindtree.demo.service;

import org.springframework.stereotype.Service;

import com.mindtree.demo.entity.Passenger;
import com.mindtree.demo.entity.Ship;

@Service
public interface ShipService {
	Ship addShip(Ship ship);

	Ship findShip(int shipId, Passenger passenger);

}
