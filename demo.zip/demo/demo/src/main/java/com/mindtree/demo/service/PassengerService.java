package com.mindtree.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.demo.entity.Passenger;

@Service
public interface PassengerService {

	Passenger addPassenger(int shipId, Passenger passenger);

	String generateTicketCode(int shipId, Passenger passenger);

	Passenger showPassenger(String ticketCode);

	List<Passenger> sortPassenger();
}
