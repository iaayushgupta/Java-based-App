package com.mindtree.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.demo.entity.Ship;
import com.mindtree.demo.service.ShipService;

@RestController
public class ShipController {

	@Autowired
	private ShipService shipservice;

	@PostMapping("/setship")
	public Ship addShip(Ship ship) {
		return shipservice.addShip(ship);
	}

}
