package com.mindtree.demo.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.demo.entity.Passenger;
import com.mindtree.demo.entity.Ship;
import com.mindtree.demo.repository.ShipRepo;
import com.mindtree.demo.service.ShipService;

@Service
public class ShipServiceImpl implements ShipService {

	@Autowired
	ShipRepo shiprepo;

	@Override
	public Ship addShip(Ship ship) {
		// TODO Auto-generated method stub
		return shiprepo.save(ship);
	}

	@Override
	public Ship findShip(int shipId, Passenger passenger) {
		// TODO Auto-generated method stub
		Ship ship = shiprepo.findById(shipId).get();
		int currentstrength = ship.getCurrentStrength();
		currentstrength++;
		ship.setCurrentStrength(currentstrength);
		ship.getPassengers().add(passenger);
		return ship;

	}

}
