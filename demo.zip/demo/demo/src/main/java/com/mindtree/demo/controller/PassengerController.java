package com.mindtree.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.demo.entity.Passenger;
import com.mindtree.demo.service.PassengerService;

@RestController
public class PassengerController {

	@Autowired
	private PassengerService passengerservice;

	@PostMapping("/setpassenger")
	Passenger addPassenger(@PathVariable int shipId, @RequestBody Passenger passenger) {
		return passengerservice.addPassenger(shipId, passenger);
	}

	@GetMapping("/getpassenger/{ticketCode}")
	Passenger showPassenger(@PathVariable String ticketCode) {
		return passengerservice.showPassenger(ticketCode);
	}

	@GetMapping("/getpassenger")
	List<Passenger> sortPassenger() {
		return passengerservice.sortPassenger();
	}
}
