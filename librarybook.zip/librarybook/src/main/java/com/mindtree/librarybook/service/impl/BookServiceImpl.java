package com.mindtree.librarybook.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.librarybook.entity.Book;
import com.mindtree.librarybook.entity.Library;
import com.mindtree.librarybook.exception.DuplicateBookException;
import com.mindtree.librarybook.exception.InvalidBookException;
import com.mindtree.librarybook.exception.ServiceException;
import com.mindtree.librarybook.repository.BookRepo;
import com.mindtree.librarybook.repository.LibraryRepo;
import com.mindtree.librarybook.service.BookService;
import com.mindtree.librarybook.service.LibraryService;

@Service
public class BookServiceImpl implements BookService {

	@Autowired
	BookRepo bookrepo;

	@Autowired
	LibraryRepo librepo;
	@Autowired
	LibraryService libraryservice;

	@Override
	public Book addlibrary( Book book) {
		// TODO Auto-generated method stub      
		return bookrepo.save(book);
	}

	

	@Override
	public List<Book> listAllBook(int libraryId) {
		Library library = librepo.findById(libraryId).get();
		return library.getBooks();
	}

	@Override
	public void deleteLibrary(int bookId) {
		// TODO Auto-generated method stub
		
	 List<Library> libraries = librepo.findAll();
		for(Library library:libraries)
			for(Book book:library.getBooks())
				if(book.getBookId()==bookId)
					book=null;
		bookrepo.deleteById(bookId);

	}

	@Override
	public Book getLibraryById(int bookId) {
		// TODO Auto-generated method stub
	    
		return bookrepo.findById(bookId).get();
	}
	public  void updateBook(Book book,Library library) {
		int bookId = book.getBookId();
		for(Book book1:library.getBooks())
			if(book1.getBookId()==bookId)
				book1=book;
	}
}
