package com.mindtree.librarybook.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.librarybook.entity.Book;
import com.mindtree.librarybook.entity.Library;
import com.mindtree.librarybook.exception.ServiceException;

@Service
public interface LibraryService {
	Library addlibrary(Library library);

	List<Library> getlibraries();

	Library getLibraryById(int libraryId);

	void deleteLibrary(int libraryId);

	Library bookLibrary(int libraryId, Book book);
}
