package com.mindtree.librarybook.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.librarybook.entity.Book;
import com.mindtree.librarybook.entity.Library;
import com.mindtree.librarybook.exception.DuplicateBookException;
import com.mindtree.librarybook.exception.InvalidBookException;
import com.mindtree.librarybook.exception.ServiceException;
import com.mindtree.librarybook.repository.LibraryRepo;
import com.mindtree.librarybook.service.LibraryService;

@Service
public class Libraryservice implements LibraryService {

	@Autowired LibraryRepo libraryrepo;
	@Override
	public Library addlibrary(Library library) {
		// TODO Auto-generated method stub
		 return libraryrepo.save(library);
		 
	}

	@Override
	public List<Library> getlibraries() {
		// TODO Auto-generated method stub
		return libraryrepo.findAll();
	}

	@Override
	public Library getLibraryById(int libraryId) {
		// TODO Auto-generated method stub
		return libraryrepo.findById(libraryId).get();
	}

	@Override
	public void deleteLibrary(int libraryId) {
		// TODO Auto-generated method stub
		libraryrepo.deleteById(libraryId);
	}

	@Override
	public Library bookLibrary(int libraryId, Book book) {
		// TODO Auto-generated method stub
		Library library = libraryrepo.findById(libraryId).get();
		library.getBooks().add(book);
		return libraryrepo.save(library);
	}

}
