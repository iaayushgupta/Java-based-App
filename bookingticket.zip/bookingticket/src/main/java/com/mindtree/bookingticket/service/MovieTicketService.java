package com.mindtree.bookingticket.service;


import org.springframework.stereotype.Service;

import com.mindtree.bookingticket.Exception.ServiceException;
import com.mindtree.bookingticket.entity.MovieTicket;

@Service
public interface MovieTicketService {
 

String addMovieTicket(MovieTicket movieticket, String portalName) throws ServiceException;

}
