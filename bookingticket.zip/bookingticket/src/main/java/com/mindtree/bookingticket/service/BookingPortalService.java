package com.mindtree.bookingticket.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.bookingticket.Exception.ServiceException;
import com.mindtree.bookingticket.entity.BookingPortal;
import com.mindtree.bookingticket.entity.MovieTicket;

@Service
public interface BookingPortalService {
 BookingPortal addBookingPortal(BookingPortal bookingportal);
 String deleteBookingPortal(int bookingPortalId) throws ServiceException;
List<BookingPortal> displayBookings();
BookingPortal getPortal(String portslName,MovieTicket movie);
}
