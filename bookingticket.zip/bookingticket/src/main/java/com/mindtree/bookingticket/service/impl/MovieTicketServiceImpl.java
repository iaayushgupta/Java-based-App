package com.mindtree.bookingticket.service.impl;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.bookingticket.Exception.NoPortalFoundException;
import com.mindtree.bookingticket.Exception.ServiceException;
import com.mindtree.bookingticket.entity.BookingPortal;
import com.mindtree.bookingticket.entity.MovieTicket;
import com.mindtree.bookingticket.repository.BookingPortalRepository;
import com.mindtree.bookingticket.repository.MovieTicketRepository;
import com.mindtree.bookingticket.service.BookingPortalService;
import com.mindtree.bookingticket.service.MovieTicketService;

@Service
public class MovieTicketServiceImpl implements MovieTicketService {

	@Autowired
	MovieTicketRepository movieticketrepository;
	@Autowired
	BookingPortalService bookingportalservice;
	@Override
	public String addMovieTicket(MovieTicket movieticket,String portalName) throws ServiceException {
		// TODO Auto-generated method stub
		BookingPortal bookingportal=bookingportalservice.getPortal(portalName, movieticket);
		if(bookingportal!=null){
			movieticket.setBookingportal(bookingportal);
			movieticketrepository.save(movieticket);
		}
		else {
			throw new NoPortalFoundException("no portal found");
		}
		return "succesfully added";
	}

	

}
