package com.mindtree.bookingticket.service.impl;

import java.util.Comparator;

import org.springframework.stereotype.Service;

import com.mindtree.bookingticket.entity.MovieTicket;

@Service
public class Sort implements Comparator<MovieTicket> {

	@Override
	public int compare(MovieTicket movie1, MovieTicket movie2) {
		if(movie1.getTicketPrice()<movie2.getTicketPrice()) {
			return 1;
		}
		else {
			return -1;
		}
	}

}
