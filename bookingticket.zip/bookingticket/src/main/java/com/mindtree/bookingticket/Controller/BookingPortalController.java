package com.mindtree.bookingticket.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.bookingticket.Exception.ServiceException;
import com.mindtree.bookingticket.entity.BookingPortal;
import com.mindtree.bookingticket.service.BookingPortalService;
import com.mindtree.bookingticket.utility.ResponseEntity;

@RestController
public class BookingPortalController {

	@Autowired
	BookingPortalService bookingportalserevice;
	
	
	@PostMapping("/setbookingdetail")
    public BookingPortal addBookingPortal(@RequestBody BookingPortal bookingportal) {
		
			
				return bookingportalserevice.addBookingPortal(bookingportal);
		
		 
		
    }
	@DeleteMapping("/deletebooking/{bookingPortalId}")
    ResponseEntity deleteBookingPortal(@PathVariable int bookingPortalId) {
		String string;
    	try {

          string=bookingportalserevice.deleteBookingPortal(bookingPortalId);
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			return new ResponseEntity("Unsuccesful","no id found",true);
		}
    	return new ResponseEntity("",string,false);
    }
	
	@GetMapping("/getbookingdetails")
	public ResponseEntity displayBookings(){
		
		List<BookingPortal> bookingportals= bookingportalserevice.displayBookings();
		if(bookingportals.size()>0) {
			return new ResponseEntity("Succesful",bookingportals,false);
		}
		else {
			return new ResponseEntity("Unsuccesful","no list present",true);
		}
	}
    
}
