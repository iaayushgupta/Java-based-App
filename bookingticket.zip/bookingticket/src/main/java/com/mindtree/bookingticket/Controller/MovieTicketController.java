package com.mindtree.bookingticket.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.bookingticket.Exception.ServiceException;
import com.mindtree.bookingticket.entity.MovieTicket;
import com.mindtree.bookingticket.service.MovieTicketService;
import com.mindtree.bookingticket.utility.ResponseEntity;

@RestController
public class MovieTicketController {

	@Autowired
	MovieTicketService movieticketservice;
	
	@PostMapping("/setmovieticket/{portalName}")
	public ResponseEntity addMovieTicket(@RequestBody MovieTicket movieticket,@PathVariable String portalName) {
		String string=null;
		try {
			 string=movieticketservice.addMovieTicket(movieticket, portalName);
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
		 return new ResponseEntity("Unsuccesful","no id found",true);
		}
		return new ResponseEntity("",string,false);
	}
	
}
