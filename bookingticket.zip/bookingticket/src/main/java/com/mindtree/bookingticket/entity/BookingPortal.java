package com.mindtree.bookingticket.entity;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class BookingPortal  {
  
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int protalId;
	@Column(unique = true)
	private String portalName;
	@OneToMany(fetch=FetchType.EAGER,mappedBy="bookingportal")
	private List<MovieTicket> movietickets;

	public BookingPortal(int protalId,String portalName, List<MovieTicket> movietickets) {
		this.protalId=protalId;
		this.portalName = portalName;
		this.movietickets = movietickets;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + getProtalId();
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookingPortal other = (BookingPortal) obj;
		if (getProtalId() != other.getProtalId())
			return false;
		return true;
	}

	public int getProtalId() {
		return protalId;
	}

	public void setProtalId(int protalId) {
		this.protalId = protalId;
	}

	public String getPortalName() {
		return portalName;
	}

	public void setPortalName(String portalName) {
		this.portalName = portalName;
	}

	public List<MovieTicket> getMovietickets() {
		return movietickets;
	}

	public void setMovietickets(List<MovieTicket> movietickets) {
		this.movietickets = movietickets;
	}

	public BookingPortal() {
		// TODO Auto-generated constructor stub
	}
	

	
}
