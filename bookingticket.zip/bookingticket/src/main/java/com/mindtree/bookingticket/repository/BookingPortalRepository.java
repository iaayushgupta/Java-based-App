package com.mindtree.bookingticket.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.bookingticket.entity.BookingPortal;

@Repository
public interface BookingPortalRepository extends JpaRepository<BookingPortal, Integer> {

}
