package com.mindtree.personpassport.service.impl;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.personpassport.entity.Person;

import com.mindtree.personpassport.repository.PersonRepo;
import com.mindtree.personpassport.service.PersonService;

@Service
public class PersonServiceImpl implements PersonService {

	@Autowired
	PersonRepo personrepo;

	@Override
	public String getPassportId(Person person) {
		// TODO Auto-generated method stub
		String name = person.getName();
		int age = person.getAge();
		String country = person.getCountry();
		String passportId = "";
		for (int i = 0; i < 2; i++) {
			passportId = passportId + name.charAt(i);
		}
		String age1 = Integer.toString(age);
		for (int i = 0; i < age1.length(); i++) {
			passportId = passportId + age1.charAt(i);
		}
		for (int i = 0; i < 2; i++) {
			passportId = passportId + country.charAt(i);
		}
		return passportId;
	}

	@Override
	public Person addPerson(Person person) {
		// TODO Auto-generated method stub
		String passportId = getPassportId(person);
		person.setPassportId(passportId);
		return personrepo.save(person);
	}

	@Override
	public List<Person> Person() {
		// TODO Auto-generated method stub
		return personrepo.findAll();

	}

	@Override
	public Person getPerson(int personId) {
		// TODO Auto-generated method stub
		return personrepo.findById(personId).get();
	}

	@Override
	public void deletePerson(int personId) {
		// TODO Auto-generated method stub
		personrepo.deleteById(personId);
	}

	@Override
	public Person getPersonDetail(String personId) {
		// TODO Auto-generated method stub
		int personId1 = Integer.parseInt(personId);

		return personrepo.findById(personId1).get();
	}

}
