package com.mindtree.personpassport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonpassportApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonpassportApplication.class, args);
	}

}
