package com.mindtree.personpassport.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mindtree.personpassport.entity.Person;
import com.mindtree.personpassport.service.PersonService;

@Controller
public class PersonController {

	@Autowired
	PersonService service;

	@RequestMapping("/")
	public String viewHomePage() {
		return "home";
	}

	@RequestMapping("/new")
	public String showNewProductPage(Model model) {
		Person person = new Person();
		model.addAttribute("person", person);

		return "addperson";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveProduct(@ModelAttribute("person") Person person) {
		service.addPerson(person);

		return "redirect:/";
	}

	@RequestMapping("/delete/{id}")
	public String deleteEmployee(@PathVariable(name = "id") int personId) {
		service.deletePerson(personId);
		return "redirect:/";
	}

	@RequestMapping("/showdetails")
	public ModelAndView showDropDown(ModelAndView mav) {
		List<Person> personlist = service.Person();
		mav.setViewName("show_details");
		mav.addObject("persons", personlist);
		return mav;
	}

	@PostMapping("/showperson")
	public ModelAndView viewHomePage(@RequestParam("personId") int id) {
		ModelAndView mav = new ModelAndView("show_result");
		Person person = service.getPerson(id);
		mav.addObject("person", person);

		return mav;
	}

//	@RequestMapping("/showperson")
//	public String submitForm(@ModelAttribute("personId") int personId, Model model) {
//		System.out.println("person id is " + personId);
//		//Person person = service.getPersonDetail(personId);
//	//	model.addAttribute("person", person);
//		
//		return "show-result";
//	}

	@RequestMapping("/edit/{id}")
	public ModelAndView showEditProductPage(@PathVariable(name = "id") int personId) {
		ModelAndView mav = new ModelAndView("edit_person");

		Person person = service.getPerson(personId);
		mav.addObject("person", person);

		return mav;
	}
}
