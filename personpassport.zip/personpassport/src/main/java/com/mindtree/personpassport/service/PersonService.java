package com.mindtree.personpassport.service;

import java.util.List;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.mindtree.personpassport.entity.Person;

@Service
public interface PersonService {
	String getPassportId(Person person);

	Person addPerson(Person person);

	List<Person> Person();

	

	Person getPersonDetail(String personName);

	Person getPerson(int personId);

	void deletePerson(int personId);

}
