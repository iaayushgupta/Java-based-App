package com.mindtree.bookingticket;

import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.mindtree.bookingticket.Controller.BookingPortalController;
import com.mindtree.bookingticket.Exception.ServiceException;
import com.mindtree.bookingticket.entity.BookingPortal;
import com.mindtree.bookingticket.entity.MovieTicket;
import com.mindtree.bookingticket.repository.BookingPortalRepository;
import com.mindtree.bookingticket.service.BookingPortalService;

@SpringBootTest
class BookingticketApplicationTests {

	@Autowired
	private BookingPortalService bookingPortalService;
	@MockBean
	private BookingPortalRepository bookingPortalRepository;

	@Test
	public void getBookingPortalService() {
		List<MovieTicket> movieTickets = new ArrayList<>();
//		movieTickets.add(new MovieTicket(1, "ddlj", 230));
//		movieTickets.add(new MovieTicket(2, "kkhh", 330));
		when(bookingPortalRepository.findAll()).thenReturn(
				Stream.of(new BookingPortal(1, "paytm", movieTickets), new BookingPortal(2, "bookmyshow", movieTickets))
						.collect(Collectors.toList()));
		assertEquals(2, bookingPortalService.displayBookings().size());
	}

	@Test
	public void saveBookingPortal() {
		BookingPortal bookingPortal = new BookingPortal(3, "phonepe");
		when(bookingPortalRepository.save(bookingPortal)).thenReturn(bookingPortal);
		assertEquals(bookingPortal, bookingPortalService.addBookingPortal(bookingPortal));
	}

	@Test
	public void deleteBookingPortal() {
		BookingPortal bookingPortal = new BookingPortal(1, "paytm");
		try {
			bookingPortalService.deleteBookingPortal(1);
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		verify(bookingPortalRepository, times(1)).deleteById(1);
	}

}
