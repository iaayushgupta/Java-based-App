package com.mindtree.bookingticket.service.impl;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.bookingticket.Exception.DeleteNotPossibleException;
import com.mindtree.bookingticket.Exception.ServiceException;
import com.mindtree.bookingticket.entity.BookingPortal;
import com.mindtree.bookingticket.entity.MovieTicket;
import com.mindtree.bookingticket.repository.BookingPortalRepository;
import com.mindtree.bookingticket.repository.MovieTicketRepository;
import com.mindtree.bookingticket.service.BookingPortalService;
import com.mindtree.bookingticket.service.MovieTicketService;

@Service
public class BookingPortalServiceImpl implements BookingPortalService {

	@Autowired
	BookingPortalRepository bookingportalrepository;
	@Autowired MovieTicketService movieticketservice;
	@Autowired MovieTicketRepository mrepo;
	@Override
	public BookingPortal addBookingPortal(BookingPortal bookingportal) {
		// TODO Auto-generated method stub
		return bookingportalrepository.save(bookingportal);
	}

	@Override
	public String deleteBookingPortal(int bookingPortalId) throws ServiceException  {
		// TODO Auto-generated method stub
	  try {
		  List<MovieTicket> res=mrepo.findAll();
		  for(MovieTicket movie:res) {
			  if(movie.getBookingportal()!=null) {
				  if(movie.getBookingportal().getProtalId()==bookingPortalId){
					  movie.setBookingportal(null);
				  }
			  }
		  }
		  mrepo.saveAll(res);
		  bookingportalrepository.deleteById(bookingPortalId);
	  }catch(Exception e) {
		  throw new DeleteNotPossibleException("portal is not found");
	  }
		return "portal has been removed";
	}

	@Override
	public List<BookingPortal> displayBookings() {
		
		List<BookingPortal> bookingportals = bookingportalrepository.findAll();
		
		// TODO Auto-generated method stub
		for(BookingPortal bookingportal:bookingportals) {
			Collections.sort(bookingportal.getMovietickets(),new Sort());
		}
		return bookingportals;
				
	}

	@Override
	public BookingPortal getPortal(String portalName, MovieTicket movie) {
		// TODO Auto-generated method stub
		List<BookingPortal> portal=bookingportalrepository.findAll();
		for(BookingPortal portal1:portal)
		{
			if(portal1.getPortalName().equals(portalName)) {
				portal1.getMovietickets().add(movie);
				return bookingportalrepository.save(portal1);
			}
			
		}
		return null;
	}

	

}
