package com.mindtree.bookingticket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookingticketApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookingticketApplication.class, args);
	}

}
