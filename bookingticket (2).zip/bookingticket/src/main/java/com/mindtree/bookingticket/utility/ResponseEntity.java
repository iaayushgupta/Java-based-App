package com.mindtree.bookingticket.utility;

public class ResponseEntity {

	private String message;
	private Object object;
	private boolean error;

	public ResponseEntity(String message, Object object, boolean error) {
		super();
		this.message = message;
		this.object = object;
		this.error = error;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getObject() {
		return object;
	}

	public void setObject(Object object) {
		this.object = object;
	}

	public boolean isError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}
}
