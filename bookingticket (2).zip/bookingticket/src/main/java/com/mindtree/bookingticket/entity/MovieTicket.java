package com.mindtree.bookingticket.entity;


import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.ManyToOne;



import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class MovieTicket  {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int movieTicketId;
	private String movieName;
	private float ticketPrice;
	
	@ManyToOne(fetch = FetchType.EAGER)
	private BookingPortal bookingportal;
	
	public MovieTicket(int movieTicketId,String movieName, float ticketPrice) {
		this.movieTicketId=movieTicketId;
		this.movieName = movieName;
		this.ticketPrice = ticketPrice;	
	}

	public int getMovieTicketId() {
		return movieTicketId;
	}

	public void setMovieTicketId(int movieTicketId) {
		this.movieTicketId = movieTicketId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public float getTicketPrice() {
		return ticketPrice;
	}

	public void setTicketPrice(float ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

	public BookingPortal getBookingportal() {
		return bookingportal;
	}

	public void setBookingportal(BookingPortal bookingportal) {
		this.bookingportal = bookingportal;
	}

	public MovieTicket() {
		// TODO Auto-generated constructor stub
	}

	
}
